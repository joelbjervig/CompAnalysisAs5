# CompAnalysisAs5
Final Assignment of Computaiotnal Image Analysis 1

Run the evaluate_classifier.m It will load the trained network net.